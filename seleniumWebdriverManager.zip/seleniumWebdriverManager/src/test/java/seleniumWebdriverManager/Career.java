package seleniumWebdriverManager;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Pages.CareersPage;
import Pages.googleSearchPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Sample {
	WebDriver driver = new ChromeDriver();
	@BeforeMethod
	public void launchBrowser() {
		WebDriverManager.chromedriver().setup();	
		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		driver.manage().window().maximize();
		
	}
	
	
	@Test
	
	public void EnterDetailsInCareer() throws InterruptedException {
		 
		JavascriptExecutor js =(JavascriptExecutor)driver;
	
		js.executeScript("arguments[0].scrollIntoView()", CareersPage.enter_name(driver));
		CareersPage.enter_name(driver).sendKeys("abcde");
		CareersPage.enter_email(driver).sendKeys("abcde@test.com");
		CareersPage.enter_phoneNumber(driver).sendKeys("987654321");
		js.executeScript("arguments[0].scrollIntoView()", CareersPage.enter_resume(driver));
		CareersPage.enter_resume(driver).sendKeys("C:\\Program Files\\Android");
		js.executeScript("arguments[0].scrollIntoView()", CareersPage.enter_Desc(driver));
		CareersPage.enter_Desc(driver).sendKeys("Applied for QA Position");
		Thread.sleep(5000);
		js.executeScript("arguments[0].scrollIntoView()", CareersPage.click_ApplyNow(driver));
		CareersPage.click_ApplyNow(driver).click();
	}
	
	
	@AfterMethod
	public void quitBrowser() {
		driver.quit();
	}
	

}
