package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CareersPage {

	private static WebElement element = null;

	public static WebElement enter_name(WebDriver driver) {
		element = driver.findElement(By.xpath("//input[@name='name']"));
		return element;

	}
	public static WebElement enter_email(WebDriver driver) {
		element = driver.findElement(By.xpath("//input[@name='email']"));
		return element;

	}
	public static WebElement enter_phoneNumber(WebDriver driver) {
		element = driver.findElement(By.xpath("//input[@name='phone']"));
		return element;

	}
	public static WebElement enter_resume(WebDriver driver) {
		element = driver.findElement(By.xpath("//input[@name='resume']"));
		return element;

	}
	public static WebElement enter_Desc(WebDriver driver) {
		element = driver.findElement(By.xpath("//textarea[@name='description']"));
		return element;

	}
	
	public static WebElement click_ApplyNow(WebDriver driver) {
		element = driver.findElement(By.xpath("//button[text()='APPLY NOW']"));
		return element;

	}

}
